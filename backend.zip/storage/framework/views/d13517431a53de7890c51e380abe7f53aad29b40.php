<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH F:\develop\Laravel\register_my_gear\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>