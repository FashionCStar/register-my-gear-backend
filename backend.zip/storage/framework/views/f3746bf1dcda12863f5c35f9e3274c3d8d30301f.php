<?php $__env->startComponent('mail::message'); ?>
# Change your password

The body of your message.

<?php $__env->startComponent('mail::button', ['url' => 'http://localhost:4200/#/auth/reset-password?token='.$token]); ?>
Change Password
<?php echo $__env->renderComponent(); ?>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH F:\develop\Laravel\register_my_gear\backend\resources\views/Email/passwordReset.blade.php ENDPATH**/ ?>