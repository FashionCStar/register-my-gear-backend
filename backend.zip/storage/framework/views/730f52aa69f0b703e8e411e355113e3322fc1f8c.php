<?php echo e($slot); ?>

<?php /**PATH F:\develop\Laravel\register_my_gear\backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>